# Spring boot + Nginx + Mongodb docker-compose example
Docker compose example - spring boot + Nginx + Mongodb

1. Execute `docker-compose build`
2. Execute `docker-compose up`
3. Go to http://localhost
